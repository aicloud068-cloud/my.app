
DROP INDEX idx_orders_created_at;
DROP INDEX idx_orders_customer_name;
DROP TABLE orders;
