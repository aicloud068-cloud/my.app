declare namespace Cloudflare {
  interface Env {
    SUPABASE_URL: string;
    SUPABASE_ANON_KEY: string;
  }
}
