import type { WoodPiece, BoardSize, CutLayout, PiecePlacement, EdgeMargins } from '@/shared/types';

interface PieceInstance {
  id: string;
  length: number;
  width: number;
  category: string;
  edgeMargins: EdgeMargins;
}

export function calculateCutLayout(boardSize: BoardSize, pieces: WoodPiece[]): CutLayout {
  // Expand pieces to individual instances
  const instances: PieceInstance[] = [];
  pieces.forEach(piece => {
    for (let i = 0; i < piece.quantity; i++) {
      instances.push({
        id: `${piece.id}-${i}`,
        length: piece.length,
        width: piece.width,
        category: piece.category,
        edgeMargins: piece.edgeMargins,
      });
    }
  });

  // Sort instances by area (largest first) for better packing
  instances.sort((a, b) => (b.length * b.width) - (a.length * a.width));

  const placements: PiecePlacement[] = [];
  const boards: { placements: PiecePlacement[], occupied: boolean[][] }[] = [];
  
  let currentBoardIndex = 0;
  boards.push(createNewBoard(boardSize));

  // Try to place each piece
  for (const instance of instances) {
    let placed = false;

    // Try current board first
    while (!placed && currentBoardIndex < boards.length) {
      const board = boards[currentBoardIndex];
      
      // Try both orientations
      for (const rotated of [false, true]) {
        const pieceLength = rotated ? instance.width : instance.length;
        const pieceWidth = rotated ? instance.length : instance.width;
        
        // Calculate margins based on rotation
        // When not rotated: top/bottom affect width dimension, left/right affect length dimension
        // When rotated: top/bottom affect length dimension, left/right affect width dimension
        let marginLeft, marginRight, marginTop, marginBottom;
        
        if (!rotated) {
          // Normal orientation
          marginLeft = instance.edgeMargins.left;
          marginRight = instance.edgeMargins.right;
          marginTop = instance.edgeMargins.top;
          marginBottom = instance.edgeMargins.bottom;
        } else {
          // Rotated 90 degrees clockwise: top becomes right, right becomes bottom, etc.
          marginLeft = instance.edgeMargins.top;
          marginRight = instance.edgeMargins.bottom;
          marginTop = instance.edgeMargins.left;
          marginBottom = instance.edgeMargins.right;
        }
        
        const totalLength = pieceLength + marginLeft + marginRight;
        const totalWidth = pieceWidth + marginTop + marginBottom;

        // Find a spot for this piece
        const position = findPosition(board.occupied, totalLength, totalWidth, boardSize);
        
        if (position) {
          // Place the piece
          const placement: PiecePlacement = {
            pieceId: instance.id.split('-')[0], // Original piece ID
            boardIndex: currentBoardIndex,
            x: position.x + marginLeft,
            y: position.y + marginTop,
            rotated,
          };
          
          placements.push(placement);
          board.placements.push(placement);
          
          // Mark area as occupied
          markOccupied(board.occupied, position.x, position.y, totalLength, totalWidth);
          placed = true;
          break;
        }
      }

      if (!placed) {
        // Try next board or create new one
        currentBoardIndex++;
        if (currentBoardIndex >= boards.length) {
          boards.push(createNewBoard(boardSize));
        }
      }
    }
  }

  // Calculate total waste
  const totalBoardArea = boards.length * boardSize.length * boardSize.width;
  const totalPieceArea = instances.reduce((sum, p) => sum + (p.length * p.width), 0);
  const totalWaste = totalBoardArea - totalPieceArea;

  return {
    boardsNeeded: boards.length,
    totalWaste,
    placements,
  };
}

function createNewBoard(boardSize: BoardSize) {
  return {
    placements: [] as PiecePlacement[],
    occupied: Array(Math.ceil(boardSize.length)).fill(null).map(() => 
      Array(Math.ceil(boardSize.width)).fill(false)
    ),
  };
}

function findPosition(
  occupied: boolean[][], 
  length: number, 
  width: number,
  boardSize: BoardSize
): { x: number; y: number } | null {
  // Simple first-fit algorithm
  for (let x = 0; x <= boardSize.length - length; x++) {
    for (let y = 0; y <= boardSize.width - width; y++) {
      if (canPlaceAt(occupied, x, y, length, width)) {
        return { x, y };
      }
    }
  }
  return null;
}

function canPlaceAt(
  occupied: boolean[][],
  x: number,
  y: number,
  length: number,
  width: number
): boolean {
  const xEnd = Math.min(Math.ceil(x + length), occupied.length);
  const yEnd = Math.min(Math.ceil(y + width), occupied[0]?.length || 0);

  for (let i = Math.floor(x); i < xEnd; i++) {
    for (let j = Math.floor(y); j < yEnd; j++) {
      if (occupied[i]?.[j]) {
        return false;
      }
    }
  }
  return true;
}

function markOccupied(
  occupied: boolean[][],
  x: number,
  y: number,
  length: number,
  width: number
): void {
  const xEnd = Math.min(Math.ceil(x + length), occupied.length);
  const yEnd = Math.min(Math.ceil(y + width), occupied[0]?.length || 0);

  for (let i = Math.floor(x); i < xEnd; i++) {
    for (let j = Math.floor(y); j < yEnd; j++) {
      if (occupied[i]?.[j] !== undefined) {
        occupied[i][j] = true;
      }
    }
  }
}
