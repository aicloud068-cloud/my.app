export interface EdgeMargins {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

export type GrainDirection = 'longitudinal' | 'transverse';

export interface WoodPiece {
  id: string;
  length: number;
  width: number;
  quantity: number;
  category: string;
  edgeMargins: EdgeMargins;
  grainDirection: GrainDirection;
}

export interface BoardSize {
  length: number;
  width: number;
}

export interface CutLayout {
  boardsNeeded: number;
  totalWaste: number;
  placements: PiecePlacement[];
}

export interface PiecePlacement {
  pieceId: string;
  boardIndex: number;
  x: number;
  y: number;
  rotated: boolean;
}
